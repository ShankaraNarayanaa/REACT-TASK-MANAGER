export const ROUTES = {
    SIGN_UP: '/signup',
    SIGN_IN: '/signin',
    BOARDS: '/boards',
    BOARD: '/boards/:board',
};
