import React from 'react';

export const AuthUserContext = React.createContext(null);
